console.log('Hola mundo desde TypeScript');

const suma = (a: number, b:number): number => a+b;

console.log(suma(5, 5));